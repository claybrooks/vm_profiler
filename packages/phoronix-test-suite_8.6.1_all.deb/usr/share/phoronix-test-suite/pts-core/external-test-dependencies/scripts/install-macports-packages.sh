#!/bin/sh
sudo port install $*
